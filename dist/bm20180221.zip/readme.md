
doing this to fix broken bookmark implementation in firefox

see here for tabs: https://developer.mozilla.org/en-US/Add-ons/WebExtensions/API/tabs

see here for popups:
https://developer.mozilla.org/en-US/Add-ons/WebExtensions/user_interface/Popups

how to get current tab
https://developer.mozilla.org/en-US/Add-ons/WebExtensions/API/tabs/getCurrent